import React from 'react';
import styles from './News.module.css';

const News = () => {
    return (
        <div>
            Newss
        </div>
    );
}

export default News;