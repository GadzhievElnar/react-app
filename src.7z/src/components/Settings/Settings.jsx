import React from 'react';
import styles from './Settings.module.css';

const Settings = () => {
    return(
        <div>
            Settings
        </div>
    );
}

export default Settings;