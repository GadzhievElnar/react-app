import { returnStatement } from '@babel/types';
import React from 'react';
import styles from './Music.module.css';

const Music = (props) => {
    return(
        <div>
            Music
        </div>
    );
}

export default Music;